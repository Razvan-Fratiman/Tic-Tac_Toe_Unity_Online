using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Events;
using UnityEngine.UI; // Add this for UI components
using TMPro; // Add this for TextMeshPro

public class Board : MonoBehaviour
{
    [Header("Input Settings : ")]
    [SerializeField] private LayerMask boxesLayerMask;
    [SerializeField] private float touchRadius;

    [Header("Mark Sprites : ")]
    [SerializeField] private Sprite spriteX;
    [SerializeField] private Sprite spriteO;

    [Header("Mark Colors : ")]
    [SerializeField] private Color colorX;
    [SerializeField] private Color colorO;

    [Header("UI References : ")]
    [SerializeField] private Button restartButton; // Reference to the restart button
    [SerializeField] private TextMeshProUGUI winnerText; // Reference to the winner display text

    public Mark[] marks;
    private Camera cam;
    private Mark currentMark;
    private bool gameEnded = false; // Track if game has ended

    private void Start()
    {
        cam = Camera.main;
        currentMark = Mark.X;
        marks = new Mark[9];

        // Set up the restart button if assigned
        if (restartButton != null)
        {
            restartButton.onClick.AddListener(RestartGame);
        }

        // Initialize winner text
        if (winnerText != null)
        {
            winnerText.text = ""; // Start with empty text
        }
    }

    private void Update()
    {
        // Only allow input if game hasn't ended
        if (!gameEnded && Mouse.current != null && Mouse.current.leftButton.wasReleasedThisFrame)
        {
            Vector2 touchPosition = cam.ScreenToWorldPoint(Mouse.current.position.ReadValue());
            Collider2D hit = Physics2D.OverlapCircle(touchPosition, touchRadius, boxesLayerMask);

            if (hit)
            {
                Box hitBox = hit.GetComponent<Box>();
                if (hitBox != null)
                {
                    HitBox(hitBox);
                }
            }
        }
    }

    private void HitBox(Box box)
    {
        if (!box.isMarked)
        {
            marks[box.index] = currentMark;
            box.SetAsMarked(GetSprite(), currentMark, GetColor());

            bool won = CheckIfWin();
            if (won)
            {
                Debug.Log(currentMark.ToString() + " Wins!");
                DisplayWinner(currentMark.ToString() + " Wins!");
                gameEnded = true;
                return;
            }
            if (CheckIfDraw())
            {
                Debug.Log("It's a Draw!");
                DisplayWinner("It's a Draw!");
                gameEnded = true;
                return;
            }
            SwitchPlayer();
        }
    }

    public void RestartGame()
    {
        // Reset game state
        gameEnded = false;
        currentMark = Mark.X;

        // Clear the marks array
        for (int i = 0; i < marks.Length; i++)
        {
            marks[i] = Mark.None;
        }

        // Reset all boxes
        Box[] boxes = FindObjectsByType<Box>(FindObjectsSortMode.None);
        foreach (Box box in boxes)
        {
            box.ResetBox();
        }

        Debug.Log("Game Restarted!");

        // Clear winner text
        if (winnerText != null)
        {
            winnerText.text = "";
        }
    }

    private void DisplayWinner(string message)
    {
        if (winnerText != null)
        {
            winnerText.text = message;
        }
    }

    private bool CheckIfDraw()
    {
        for (int i = 0; i < marks.Length; i++)
        {
            if (marks[i] == Mark.None)
            {
                return false;
            }
        }
        return true;
    }

    private bool AreBoxesMatched(int i, int j, int k)
    {
        Mark m = currentMark;
        bool matched = (marks[i] == m && marks[j] == m && marks[k] == m);
        return matched;
    }

    private bool CheckIfWin()
    {
        return
        AreBoxesMatched(0, 1, 2) || AreBoxesMatched(3, 4, 5) || AreBoxesMatched(6, 7, 8) ||
        AreBoxesMatched(0, 3, 6) || AreBoxesMatched(1, 4, 7) || AreBoxesMatched(2, 5, 8) ||
        AreBoxesMatched(0, 4, 8) || AreBoxesMatched(2, 4, 6);
    }

    private void SwitchPlayer()
    {
        currentMark = (currentMark == Mark.X) ? Mark.O : Mark.X;
    }

    private Color GetColor()
    {
        return (currentMark == Mark.X) ? colorX : colorO;
    }

    private Sprite GetSprite()
    {
        return (currentMark == Mark.X) ? spriteX : spriteO;
    }
}