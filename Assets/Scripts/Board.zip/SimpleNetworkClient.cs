using UnityEngine;
using System.Net.Sockets;
using System.Text;

public class SimpleNetworkClient : MonoBehaviour
{
    public string serverIP = "127.0.0.1";
    public int serverPort = 7777;

    private TcpClient client;
    private NetworkStream stream;

    public void ConnectToServer()
    {
        try
        {
            client = new TcpClient(serverIP, serverPort);
            stream = client.GetStream();
            Debug.Log("Connected to server.");
        }
        catch (SocketException e)
        {
            Debug.LogError($"Failed to connect: {e.Message}");
        }
    }

    public void SendMessageToServer(string message)
    {
        if (client == null || !client.Connected || stream == null)
        {
            Debug.LogWarning(" Cannot send message. Not connected.");
            return;
        }

        try
        {
            byte[] data = Encoding.UTF8.GetBytes(message + "\n");
            stream.Write(data, 0, data.Length);
            Debug.Log("Message sent.");
        }
        catch (System.Exception e)
        {
            Debug.LogError($" Send failed: {e.Message}");
        }
    }

    public void Disconnect()
    {
        stream?.Close();
        client?.Close();
        Debug.Log(" Disconnected from server.");
    }

    private void OnApplicationQuit()
    {
        Disconnect();
    }
}
